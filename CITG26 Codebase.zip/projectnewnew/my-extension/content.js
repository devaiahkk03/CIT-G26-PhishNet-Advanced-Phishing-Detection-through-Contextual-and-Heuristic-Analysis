// This script runs in the context of web pages
// It can interact with the page content if needed

// Listen for messages from the background script
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "analyzeDOM") {
      // You could add additional page analysis here
      // For example, checking for login forms, sensitive input fields, etc.
      
      const sensitiveInputs = document.querySelectorAll('input[type="password"]').length > 0;
      const loginForm = document.querySelectorAll('form').length > 0;
      
      sendResponse({
        hasSensitiveInputs: sensitiveInputs,
        hasLoginForm: loginForm
      });
    }
    return true;
  });