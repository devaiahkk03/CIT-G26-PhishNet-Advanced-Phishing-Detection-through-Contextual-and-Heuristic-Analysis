document.addEventListener("DOMContentLoaded", async () => {
    try {
      // Get the active tab
      const tabs = await browser.tabs.query({ active: true, currentWindow: true });
      const currentTab = tabs[0];
      
      // Display the current URL
      document.getElementById("current-url").textContent = currentTab.url;
      
      // Get the stored analysis result for this tab
      const key = `tab${currentTab.id}`;
      const data = await browser.storage.local.get(key);
      
      if (data[key] && data[key].result) {
        const result = data[key].result;
        const statusElement = document.getElementById("status");
        const detailsElement = document.getElementById("details");
        
        // Update the UI based on the result
        switch (result.status) {
          case "safe":
            statusElement.textContent = "✓ This website appears to be safe";
            statusElement.className = "status safe";
            break;
          case "suspicious":
            statusElement.textContent = "⚠️ This website looks suspicious";
            statusElement.className = "status suspicious";
            break;
          case "dangerous":
            statusElement.textContent = "🚫 This website is dangerous";
            statusElement.className = "status dangerous";
            break;
          default:
            statusElement.textContent = "? This website's safety is unknown";
            statusElement.className = "status unknown";
        }
        
        // Add details
        detailsElement.innerHTML = `
          <p><strong>Analysis:</strong> ${result.message}</p>
          ${result.similarTo ? `<p><strong>Similar to:</strong> ${result.similarTo}</p>` : ''}
        `;
      } else {
        // If no result was found, analyze the current URL
        const normalizedUrl = currentTab.url.toLowerCase()
          .replace(/^https?:\/\//, "")
          .replace(/^www\./, "")
          .split('/')[0];
          
        document.getElementById("status").textContent = 
          "This page hasn't been analyzed yet. Please refresh the page.";
      }
    } catch (error) {
      console.error("Error in popup:", error);
      document.getElementById("status").textContent = "Error analyzing this page.";
      document.getElementById("status").className = "status dangerous";
    }
  });