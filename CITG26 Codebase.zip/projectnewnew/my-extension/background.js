// Load phishing and safe website lists
let scamWebsites = new Set();
let popularWebsites = new Set();

// Normalize URL function - similar to your Python version
function normalizeUrl(url) {
  try {
    // Convert to lowercase
    url = url.toLowerCase();
    
    // Remove protocol (http://, https://)
    url = url.replace(/^https?:\/\//, "");
    
    // Remove 'www.' if present
    if (url.startsWith('www.')) {
      url = url.substring(4);
    }
    
    // Remove path, query parameters, and fragments
    url = url.split('/')[0];
    
    return url;
  } catch (e) {
    console.error("URL normalization error:", e);
    return url;
  }
}

// Load scam websites from a local file
fetch(browser.runtime.getURL("urlhaus-filter-ag-online.txt"))
  .then(response => response.text())
  .then(data => {
    const lines = data.split("\n");
    for (const line of lines) {
      // Skip comments and empty lines
      if (line.trim() === "" || line.startsWith("//") || line.startsWith("#") || line.startsWith("!")) {
        continue;
      }
      
      // Clean up the URL
      let url = line.trim();
      url = url.replace(/^"/, "").replace(/"$/, ""); // Remove surrounding quotes
      url = normalizeUrl(url);
      
      if (url) {
        scamWebsites.add(url);
      }
    }
    console.log(`Loaded ${scamWebsites.size} scam websites`);
  })
  .catch(error => console.error("Error loading scam websites:", error));

// Load popular websites
fetch(browser.runtime.getURL("top-1000-websites.txt"))
  .then(response => response.text())
  .then(data => {
    const lines = data.split("\n");
    for (const line of lines) {
      // Skip comments and empty lines
      if (line.trim() === "" || line.startsWith("//") || line.startsWith("#") || line.startsWith("!")) {
        continue;
      }
      
      // Clean up the URL
      let url = line.trim();
      url = url.replace(/^"/, "").replace(/"$/, ""); // Remove surrounding quotes
      url = normalizeUrl(url);
      
      if (url) {
        popularWebsites.add(url);
      }
    }
    console.log(`Loaded ${popularWebsites.size} popular websites`);
  })
  .catch(error => console.error("Error loading popular websites:", error));

// Function to check if a URL is a phishing site
function checkUrl(url) {
  const normalizedUrl = normalizeUrl(url);
  
  // Check if it's a known scam website
  if (scamWebsites.has(normalizedUrl)) {
    return {
      status: "dangerous",
      message: "This website is known to be dangerous."
    };
  }
  
  // Check if it's a popular website
  if (popularWebsites.has(normalizedUrl)) {
    return {
      status: "safe",
      message: "This is a known popular website."
    };
  }
  
  // Check similarity to popular websites
  for (const popularSite of popularWebsites) {
    const similarity = calculateSimilarity(normalizedUrl, popularSite);
    if (similarity > 0.7 && normalizedUrl !== popularSite) {
      return {
        status: "suspicious",
        message: `This URL is suspiciously similar to ${popularSite} (similarity: ${similarity.toFixed(2)})`,
        similarTo: popularSite
      };
    }
  }
  
  return {
    status: "unknown",
    message: "This website is not in our database."
  };
}

// Simple similarity function (Levenshtein-like)
function calculateSimilarity(str1, str2) {
  // Function adapted for JavaScript
  // This is a simple version - for production, consider using a proper Levenshtein distance library
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) {
    return 1.0;
  }
  
  const editDistance = levenshteinDistance(longer, shorter);
  return (longer.length - editDistance) / parseFloat(longer.length);
}

function levenshteinDistance(str1, str2) {
  const m = str1.length;
  const n = str2.length;
  
  // Create a matrix of size (m+1) x (n+1)
  const dp = Array(m + 1).fill().map(() => Array(n + 1).fill(0));
  
  // Fill the first row and column
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  
  // Fill the rest of the matrix
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = str1[i - 1] !== str2[j - 1] ? 1 : 0;
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,      // deletion
        dp[i][j - 1] + 1,      // insertion
        dp[i - 1][j - 1] + cost  // substitution
      );
    }
  }
  
  return dp[m][n];
}

// Listen for tab updates and check the URL
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    const result = checkUrl(changeInfo.url);
    
    // Update the badge based on the result
    let badgeText = "";
    let badgeColor = "";
    
    switch (result.status) {
      case "dangerous":
        badgeText = "⚠️";
        badgeColor = "#FF0000"; // Red
        browser.notifications.create({
          type: "basic",
          title: "PhishGuard Warning",
          message: `${changeInfo.url} is flagged as dangerous: ${result.message}`,
          iconUrl: browser.runtime.getURL("icon.png") || ""
        });
        break;
      case "suspicious":
        badgeText = "?";
        badgeColor = "#FFA500"; // Orange
        browser.notifications.create({
          type: "basic",
          title: "PhishGuard Alert",
          message: `${changeInfo.url} is flagged as suspicious: ${result.message}`,
          iconUrl: browser.runtime.getURL("icon.png") || ""
        });
        break;
      case "safe":
        badgeText = "✓";
        badgeColor = "#00FF00"; // Green
        break;
    }
    
    // Update badge
    browser.browserAction.setBadgeText({ text: badgeText, tabId: tabId });
    browser.browserAction.setBadgeBackgroundColor({ color: badgeColor, tabId: tabId });
    
    // Store the result for this tab to display in popup
    browser.storage.local.set({ [`tab${tabId}`]: { url: changeInfo.url, result: result } });
  }
});