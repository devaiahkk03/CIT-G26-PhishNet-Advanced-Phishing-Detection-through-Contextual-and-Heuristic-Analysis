import difflib
from flask import Flask, request, render_template

app = Flask(__name__)

def normalize_url(url):
    """
    Normalize a URL/domain by:
      - Converting to lowercase
      - Removing leading http:// or https://
      - Stripping trailing slashes
    """
    url = url.lower()
    if url.startswith("http://"):
        url = url[len("http://"):]
    elif url.startswith("https://"):
        url = url[len("https://"):]
    return url.rstrip("/")

def load_local_scam_websites(filepath):
    """
    Loads scam websites from a local text file.
    Ignores lines starting with "!" or "#" (metadata/comments),
    removes the leading "||" if present, and strips surrounding quotes.
    URLs are normalized.
    """
    try:
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        print(f"Error loading local scam website list: {e}")
        return set()
    
    websites = set()
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("!") or line.startswith("#"):
            continue
        if line.startswith("||"):
            line = line[2:]
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        websites.add(normalize_url(line))
    return websites

def load_popular_websites(filepath):
    """
    Loads popular websites from a local text file.
    Ignores lines starting with "//", "!" or "#" and strips surrounding quotes.
    The domains are normalized.
    """
    try:
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        print(f"Error loading popular website list: {e}")
        return set()
    
    websites = set()
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("!") or line.startswith("#"):
            continue
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        websites.add(normalize_url(line))
    return websites

# File paths for the lists
SCAM_LIST_FILE = r"C:\Users\Devaiah K K\Downloads\projectnewnew\urlhaus-filter-ag-online.txt"
POPULAR_LIST_FILE = r"C:\Users\Devaiah K K\Downloads\projectnewnew\top-1000-websites.txt"

# Load the lists (normalized)
scam_websites = load_local_scam_websites(SCAM_LIST_FILE)
popular_websites = load_popular_websites(POPULAR_LIST_FILE)

def is_scam(url):
    """
    Classify a URL as:
       - dangerous: if it exactly matches a known scam website
       - safe: if it exactly matches a popular website
       - suspicious: if it is very similar (similarity >0.7) to a popular website
       - unknown: if none of the above conditions apply
    """
    norm = normalize_url(url)
    
    if norm in scam_websites:
        return "dangerous", "Exact match with known dangerous website."
    
    if norm in popular_websites:
        return "safe", "Exact match with popular website."
    
    for pop in popular_websites:
        ratio = difflib.SequenceMatcher(None, norm, pop).ratio()
        if ratio > 0.7 and norm != pop:
            return "suspicious", f"URL is suspiciously similar to '{pop}' (similarity: {ratio:.2f})."
    
    return "unknown", "Website not found in our lists."

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        test_url = request.form.get("url").strip()
        # Remove surrounding quotes if present
        if test_url.startswith('"') and test_url.endswith('"'):
            test_url = test_url[1:-1]
        classification, message = is_scam(test_url)
        if classification == "dangerous":
            result = f"Danger: The website '{test_url}' is flagged as dangerous. Reason: {message}"
        elif classification == "suspicious":
            result = f"Suspicious: The website '{test_url}' is flagged as suspicious. Reason: {message}"
        elif classification == "safe":
            result = f"Safe: The website '{test_url}' appears safe. Reason: {message}"
        else:
            result = f"Unknown: The website '{test_url}' could not be classified. Reason: {message}"
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")