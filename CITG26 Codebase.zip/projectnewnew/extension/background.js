// Utility to normalize URLs
function normalizeUrl(url) {
    url = url.toLowerCase();
    url = url.replace(/^https?:\/\//, "");
    return url.replace(/\/+$/, "");
}

let scamWebsites = new Set();
let popularWebsites = new Set();

// Load the lists from packaged files
async function loadLists() {
    try {
        let scamResponse = await fetch(chrome.runtime.getURL("urlhaus-filter-ag-online.txt"));
        let scamText = await scamResponse.text();
        scamText.split(/\r?\n/).forEach(line => {
            line = line.trim();
            if (line && !line.startsWith("!") && !line.startsWith("#")) {
                if (line.startsWith('||')) {
                    line = line.substring(2);
                }
                line = line.replace(/^"|"$/g, "");
                scamWebsites.add(normalizeUrl(line));
            }
        });

        let popResponse = await fetch(chrome.runtime.getURL("top-1000-websites.txt"));
        let popText = await popResponse.text();
        popText.split(/\r?\n/).forEach(line => {
            line = line.trim();
            if (line && !line.startsWith("//") && !line.startsWith("!") && !line.startsWith("#")) {
                line = line.replace(/^"|"$/g, "");
                popularWebsites.add(normalizeUrl(line));
            }
        });

    } catch (e) {
        console.error("Error loading lists:", e);
    }
}

function checkUrl(url) {
    const norm = normalizeUrl(url);

    if (scamWebsites.has(norm)) {
        return { classification: "dangerous", message: "Exact match with known dangerous website." };
    }
    if (popularWebsites.has(norm)) {
        return { classification: "safe", message: "Exact match with popular website." };
    }

    // Check similarity
    for (let pop of popularWebsites) {
        // Simple similarity using Levenshtein-like ratio (here you can improve your algorithm)
        // For a real implementation, consider using a library
        let ratio = similar(norm, pop);
        if (ratio > 0.8 && norm !== pop) {
            return { classification: "suspicious", message: `URL is very similar to '${pop}' (similarity: ${ratio.toFixed(2)})` };
        }
    }

    return { classification: "unknown", message: "Website not found in our lists." };
}

// A simple similarity function (for illustration purposes)
function similar(s1, s2) {
    // Using a basic algorithm: normalized common character count / average length
    let common = 0;
    for (let i = 0; i < s1.length; i++) {
        if (s2.indexOf(s1[i]) !== -1) common++;
    }
    return common / ((s1.length + s2.length) / 2);
}

// Listen for tab updates and check the URL
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
        const result = checkUrl(changeInfo.url);
        // For dangerous or suspicious URLs, you might display a notification:
        if (result.classification === "dangerous" || result.classification === "suspicious") {
            chrome.notifications.create({
                type: "basic",
                iconUrl: "icon.png",
                title: "Phishing Detector Warning",
                message: `The website ${changeInfo.url} is flagged as ${result.classification}: ${result.message}`
            });
        }
        // You could also update the extension badge
        chrome.action.setBadgeText({ text: (result.classification === "safe") ? "OK" : "!!", tabId: tabId });
    }
});

// Initialize lists when the extension starts
loadLists();