document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("status").textContent = "Phishing Detector is active.";
});
```‬

In this example:

• The extension packages your URL lists (place the files “urlhaus-filter-ag-online.txt” and “top-1000-websites.txt” in your extension folder).  
• The background script loads these files, normalizes the URLs, and listens for tab updates.  
• When the URL changes, it checks if it is dangerous, safe, or suspicious using a simple similarity function (you might substitute a more robust algorithm).  
• If a dangerous or suspicious URL is detected, the extension issues a notification (and you can also change the browser action badge).

You’d then load your extension into Firefox using about:debugging → This Firefox and click “Load Temporary Add-on” and select your manifest.json. From there, as you type or navigate to URLs, the extension can automatically check them.

This approach preserves your core detection logic (ported to JavaScript) and integrates it into a Firefox extension.// filepath: c:\Users\Devaiah K K\Downloads\projectnewnew\extension\popup.js
document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("status").textContent = "Phishing Detector is active.";
});
```‬

In this example:

• The extension packages your URL lists (place the files “urlhaus-filter-ag-online.txt” and “top-1000-websites.txt” in your extension folder).  
• The background script loads these files, normalizes the URLs, and listens for tab updates.  
• When the URL changes, it checks if it is dangerous, safe, or suspicious using a simple similarity function (you might substitute a more robust algorithm).  
• If a dangerous or suspicious URL is detected, the extension issues a notification (and you can also change the browser action badge).

You’d then load your extension into Firefox using about:debugging → This Firefox and click “Load Temporary Add-on” and select your manifest.json. From there, as you type or navigate to URLs, the extension can automatically check them.

This approach preserves your core detection logic (ported to JavaScript) and integrates it into a Firefox extension.