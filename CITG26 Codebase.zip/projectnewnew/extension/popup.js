document.addEventListener("DOMContentLoaded", () => {
    const statusEl = document.getElementById("status");
    if (statusEl) {
        statusEl.textContent = "Phishing Detector is active.";
    } else {
        console.error("No element with ID 'status' found in popup.html.");
    }
});