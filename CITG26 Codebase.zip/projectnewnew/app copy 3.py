import difflib
from flask import Flask, request, render_template
from urllib.parse import urlparse
import requests
import socket
import ssl
import json
import whois
from datetime import datetime


app = Flask(__name__)

def get_certificate_info(domain):
    """Get SSL certificate information for a domain"""
    try:
        # Create an SSL context
        context = ssl.create_default_context()
        # Connect to the domain with SSL
        with socket.create_connection((domain, 443), timeout=3) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                
                # Extract relevant information
                cert_info = {
                    'subject': cert.get('subject'),
                    'issuer': cert.get('issuer'),
                    'notBefore': cert.get('notBefore'),
                    'notAfter': cert.get('notAfter'),
                    'subjectAltName': cert.get('subjectAltName'),
                    'serialNumber': cert.get('serialNumber'),
                    'version': cert.get('version'),
                    'OCSP': cert.get('OCSP'),
                    'caIssuers': cert.get('caIssuers'),
                    'crlDistributionPoints': cert.get('crlDistributionPoints')
                }
                return cert_info
    except Exception as e:
        print(f"SSL Certificate error: {e}")
        return None

def get_geolocation(ip_address):
    """Get geolocation data for an IP address"""
    try:
        response = requests.get(f"https://ipinfo.io/{ip_address}/json")
        if response.status_code == 200:
            return response.json()
        return None
    except Exception as e:
        print(f"Geolocation error: {e}")
        return None

def get_domain_info(url):
    """Get comprehensive domain information"""
    try:
        # Extract domain from URL
        domain = normalize_url(url)
        
        # Get domain IP address
        try:
            ip_address = socket.gethostbyname(domain)
        except:
            ip_address = None
        
        # Get SSL certificate information
        cert_info = get_certificate_info(domain)
        
        # Get geolocation data
        geo_data = get_geolocation(ip_address) if ip_address else None
        
        # Get WHOIS data
        try:
            whois_data = whois.whois(domain)
        except:
            whois_data = None
        
        # Calculate domain age if creation date is available
        domain_age = None
        if whois_data and whois_data.creation_date:
            if isinstance(whois_data.creation_date, list):
                creation_date = whois_data.creation_date[0]
            else:
                creation_date = whois_data.creation_date
                
            if creation_date:
                domain_age = (datetime.now() - creation_date).days
        
        return {
            'domain': domain,
            'ip_address': ip_address,
            'certificate': cert_info,
            'geolocation': geo_data,
            'whois': whois_data,
            'domain_age_days': domain_age
        }
    except Exception as e:
        print(f"Domain info error: {e}")
        return None

def normalize_url(url):
    """
    Normalize a URL by extracting its main domain:
      - Converting to lowercase
      - Removing leading http://, https:// and www.
      - Ignoring path, query, and fragment components
    """
    try:
        url = url.lower()
        
        # Handle URLs without scheme by adding one temporarily for parsing
        if not url.startswith(('http://', 'https://')):
            parsed = urlparse('http://' + url)
        else:
            parsed = urlparse(url)
        
        # Use netloc if populated; fallback to path if netloc is empty (for bare domains)
        domain = parsed.netloc if parsed.netloc else parsed.path
        
        # Remove www. prefix if present
        if domain.startswith("www."):
            domain = domain[4:]
            
        return domain.rstrip("/")
    except:
        # Fallback to simple normalization if URL parsing fails
        if url.startswith("http://"):
            url = url[len("http://"):]
        elif url.startswith("https://"):
            url = url[len("https://"):]
        if url.startswith("www."):
            url = url[len("www."):]
        return url.rstrip("/")

def load_local_scam_websites(filepath):
    """
    Loads scam websites from a local text file.
    Ignores lines starting with "!" or "#" (metadata/comments),
    removes the leading "||" if present, and strips surrounding quotes.
    URLs are normalized.
    """
    try:
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        print(f"Error loading local scam website list: {e}")
        return set()
    
    websites = set()
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("!") or line.startswith("#"):
            continue
        if line.startswith("||"):
            line = line[2:]
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        websites.add(normalize_url(line))
    return websites

def load_popular_websites(filepath):
    """
    Loads popular websites from a local text file.
    Ignores lines starting with "//", "!" or "#" and strips surrounding quotes.
    The domains are normalized.
    """
    try:
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        print(f"Error loading popular website list: {e}")
        return set()
    
    websites = set()
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("//") or line.startswith("!") or line.startswith("#"):
            continue
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        websites.add(normalize_url(line))
    return websites

# File paths for the lists
SCAM_LIST_FILE = r"C:\Users\Devaiah K K\Downloads\projectnewnew\urlhaus-filter-ag-online.txt"
POPULAR_LIST_FILE = r"C:\Users\Devaiah K K\Downloads\projectnewnew\top-1000-websites.txt"

# Load the lists (normalized)
scam_websites = load_local_scam_websites(SCAM_LIST_FILE)
popular_websites = load_popular_websites(POPULAR_LIST_FILE)

def is_scam(url):
    """
    Classify a URL as:
       - dangerous: if it exactly matches a known scam website
       - safe: if it exactly matches a popular website
       - suspicious: if it is very similar (similarity >0.7) to a popular website
       - unknown: if none of the above conditions apply
       
    Returns classification, message, and additional domain data
    """
    norm = normalize_url(url)
    
    # Get detailed domain information
    domain_info = get_domain_info(url)
    
    if norm in scam_websites:
        return "dangerous", "Exact match with known dangerous website.", domain_info
    
    if norm in popular_websites:
        return "safe", "Exact match with popular website.", domain_info
    
    # Additional checks based on domain info
    if domain_info:
        # Check domain age - new domains are more suspicious
        if domain_info['domain_age_days'] is not None and domain_info['domain_age_days'] < 30:
            return "suspicious", f"Domain is very new (only {domain_info['domain_age_days']} days old), which is common for phishing sites.", domain_info
    
    # Check similarity to known popular domains
    for pop in popular_websites:
        ratio = difflib.SequenceMatcher(None, norm, pop).ratio()
        if ratio > 0.7 and norm != pop:
            return "suspicious", f"URL is suspiciously similar to '{pop}' (similarity: {ratio:.2f}).", domain_info
    
    return "unknown", "Website not found in our lists.", domain_info

@app.route("/", methods=["GET", "POST"])
def index():
    # Combined version that uses the modern template
    result = None
    classification = None
    message = None
    test_url = None
    domain_info = None
    
    if request.method == "POST":
        test_url = request.form.get("url", "").strip()
        # Remove surrounding quotes if present
        if test_url.startswith('"') and test_url.endswith('"'):
            test_url = test_url[1:-1]
        
        classification, message, domain_info = is_scam(test_url)
        
        if classification == "dangerous":
            result = f"Danger: The website '{test_url}' is flagged as dangerous. Reason: {message}"
        elif classification == "suspicious":
            result = f"Suspicious: The website '{test_url}' is flagged as suspicious. Reason: {message}"
        elif classification == "safe":
            result = f"Safe: The website '{test_url}' appears safe. Reason: {message}"
        else:
            result = f"Unknown: The website '{test_url}' could not be classified. Reason: {message}"
    
    return render_template("index-modern.html", 
                          result=result, 
                          classification=classification, 
                          message=message, 
                          test_url=test_url, 
                          domain_info=domain_info)

@app.route("/classic", methods=["GET", "POST"])
def classic_index():
    # Update the classic route similarly
    result = None
    classification = None
    domain_info = None
    
    if request.method == "POST":
        test_url = request.form.get("url", "").strip()
        if test_url.startswith('"') and test_url.endswith('"'):
            test_url = test_url[1:-1]
            
        classification, message, domain_info = is_scam(test_url)
        
        if classification == "dangerous":
            result = f"Danger: The website '{test_url}' is flagged as dangerous. Reason: {message}"
        elif classification == "suspicious":
            result = f"Suspicious: The website '{test_url}' is flagged as suspicious. Reason: {message}"
        elif classification == "safe":
            result = f"Safe: The website '{test_url}' appears safe. Reason: {message}"
        else:
            result = f"Unknown: The website '{test_url}' could not be classified. Reason: {message}"
            
    return render_template("index.html", result=result, classification=classification, domain_info=domain_info)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")