document.addEventListener("DOMContentLoaded", () => {
    console.log("Phishing Detector loaded.");
    
    const form = document.getElementById("detector-form");
    form.addEventListener("submit", (e) => {
        const urlInput = document.getElementById("url");
        if (urlInput.value.trim() === "") {
            alert("Please enter a valid URL.");
            e.preventDefault();
        }
    });
});