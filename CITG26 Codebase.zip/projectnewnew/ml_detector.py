import re
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

def extract_url_features(url):
    """Extract features from a URL for machine learning classification"""
    features = []
    
    # Length-based features
    features.append(len(url))
    
    # Character distribution features
    features.append(len(re.findall('[0-9]', url)) / (len(url) or 1))  # Digit ratio
    features.append(len(re.findall('[a-z]', url)) / (len(url) or 1))  # Lowercase ratio
    features.append(len(re.findall('[A-Z]', url)) / (len(url) or 1))  # Uppercase ratio
    features.append(len(re.findall('[^a-zA-Z0-9]', url)) / (len(url) or 1))  # Special char ratio
    
    # URL structure features
    features.append(url.count('.'))  # Number of dots
    features.append(url.count('/'))  # Number of slashes
    features.append(url.count('-'))  # Number of hyphens
    features.append(url.count('_'))  # Number of underscores
    features.append(url.count('='))  # Number of equals signs
    features.append(url.count('?'))  # Number of question marks
    features.append(url.count('&'))  # Number of ampersands
    
    return np.array(features).reshape(1, -1)

class MLPhishingDetector:
    def __init__(self):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.is_trained = False
        
    def train(self, urls, labels):
        """Train the model on a list of URLs and their corresponding labels (1 for phishing, 0 for legitimate)"""
        # Extract features from all URLs
        X = np.vstack([extract_url_features(url) for url in urls])
        y = np.array(labels)
        
        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train the model
        self.model.fit(X_train, y_train)
        
        # Evaluate the model
        y_pred = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        report = classification_report(y_test, y_pred)
        
        self.is_trained = True
        
        return {
            'accuracy': accuracy,
            'report': report,
            'train_size': len(X_train),
            'test_size': len(X_test)
        }
    
    def predict(self, url):
        """Predict whether a URL is phishing (1) or legitimate (0)"""
        if not self.is_trained:
            raise Exception("Model is not trained yet")
        
        features = extract_url_features(url)
        prediction = self.model.predict(features)[0]
        probability = self.model.predict_proba(features)[0]
        
        return {
            'prediction': int(prediction),
            'confidence': float(probability[1]) if prediction == 1 else float(probability[0]),
            'is_phishing': bool(prediction == 1)
        }