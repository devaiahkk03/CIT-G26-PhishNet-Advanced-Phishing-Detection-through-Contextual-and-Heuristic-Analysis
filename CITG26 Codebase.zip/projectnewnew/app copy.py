import difflib
from flask import Flask, request, render_template

app = Flask(__name__)

def load_local_scam_websites(filepath):
    """
    Loads scam websites from a local text file.
    Ignores lines starting with "!" or "#" (metadata/comments),
    removes the leading "||" if present,
    and strips surrounding double quotes if present.
    """
    try:
        with open(filepath, "r") as f:
            content = f.read()
    except Exception as e:
        print(f"Error loading local scam website list: {e}")
        return set()
    
    websites = set()
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("!") or line.startswith("#"):
            continue
        if line.startswith("||"):
            line = line[2:]
        # Remove surrounding quotes if present
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
        websites.add(line)
    return websites

# Path to your local scam website list text file
SCAM_LIST_FILE = r"C:\Users\Devaiah K K\Downloads\projectnewnew\urlhaus-filter-ag-online.txt"

# Load scam websites from the local file
scam_websites = load_local_scam_websites(SCAM_LIST_FILE)

# A set of popular websites for similarity comparison
popular_websites = {
    "http://paypal.com",
    "http://amazon.com",
    "http://google.com",
    "http://facebook.com"
}

def is_scam(url):
    # Step 1: Check if it's an exact known scam website (from the local file list)
    if url in scam_websites:
        return True, "Exact match with known scam website."
    
    # Step 2: Check similarity to popular websites
    for popular in popular_websites:
        ratio = difflib.SequenceMatcher(None, url.lower(), popular.lower()).ratio()
        if ratio > 0.8 and url.lower() != popular.lower():
            return True, f"URL is very similar to {popular} (similarity: {ratio:.2f})."
    
    return False, "No suspicious similarities detected."

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        test_url = request.form.get("url").strip()
        # Also remove quotes from user input if present
        if test_url.startswith('"') and test_url.endswith('"'):
            test_url = test_url[1:-1]
        scam, reason = is_scam(test_url)
        if scam:
            result = f"Warning: The website '{test_url}' is flagged as suspicious. Reason: {reason}"
        else:
            result = f"The website '{test_url}' appears safe. Reason: {reason}"
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")